# Nandani Singh's Portfolio

## 👩‍💻 About Me

I am a passionate developer with a strong foundation in web development and a keen interest in UI/UX design. I enjoy creating user-friendly applications and enhancing user experiences.


## Demo

[Cheakout](https://portfolio-alpha-ruddy-68.vercel.app/) 

## 🌐 Connect with Me

- [LinkedIn](https://www.linkedin.com/in/nandanisingh85/)
- [GitHub](https://github.com/nks854338)

## 📧 Contact

Feel free to reach out via email at: [your.email@example.com](snandani.tech@gmail.com)

## 🚀 Let's Build Something Great Together!
